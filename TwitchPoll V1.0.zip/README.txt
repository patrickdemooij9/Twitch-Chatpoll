1) Open TwitchPoll

2) Get a OAuth token from here: http://twitchapps.com/tmi/ (Needed to connect to your chat)

3) Enter your twitch username and OAuth token and connect to twitch

4) Click the start button (Question and answers can already be entered here if you want)

5) Click "OBS" (in the bottom left)

6) In OBS, or any streaming software, add new Window Capture for the "TwitchPoll" window. Uncheck "Capture Cursor"

7) Use CTRL+ALT to resize the window in OBS if it doesn't display the window properly

8) Right click new Window Capture, select Filter

9) Add new filter (in the bottom left), select Chroma Key

10) Set Key Color Type to "Magenta." Set Similarity to 300. Default on the rest is great.

11) Scale the window in OBS to however large you like

12) Write your question and answers for your poll and click update

13) Enjoy your poll system!

~Patrick